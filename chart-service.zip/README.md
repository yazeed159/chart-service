# chart-service — trade.log's backend

Flask API deployed on **Render**, backing the `web-service` frontend
(Cloudflare Pages + Supabase). Replaces what used to be an n8n workflow —
every route here has a 1:1 request/response contract with the webhook it
replaced, but there's no n8n in the loop anymore.

## Routes

**Chart generation** (`charts.py` + `market_data.py`)
- `POST /generate-chart` — VWAP/EMA9/EMA20/MACD at entry + a minute-bar
  window for one trade, plus best-effort volume/float context
  (`avg_volume_30d`, `relative_volume`, `float_shares`). Source: Polygon.io
  consolidated tape.
- `POST /generate-daily-chart` — daily bars strictly before a trade date
  (never the trade day itself) + a no-LLM pivot-cluster support/resistance
  guess, for the Support/Resistance feature.
- `POST /tick-data` — real Polygon trade prints for a ≤5-minute window, for
  Rewind's "real ticks" mode. Always returns 200; empty `ticks: []` on any
  failure rather than an error, since the frontend treats "nothing came
  back" and "couldn't reach the server" the same way (falls back to
  simulated ticks).

**Backtester** (`backtest_routes.py` + `engine.py` / `orb_strategy.py` /
`polygon_client.py`) — auth-gated (`Authorization: Bearer <supabase token>`)
- `POST /backtest/start` → `{job_id}`; `GET /backtest/status/<job_id>`
  (poll); `GET /backtest/defaults`; `GET|DELETE /backtest/history[/<job_id>]`;
  `GET /backtest/history/<job_id>/report`; `POST
  /backtest/history/<job_id>/enrich` (per-trade AI verdicts merged back
  onto one run's own saved report only — never the real journal).
  History/reports are stored in Supabase (`backtest_runs`, scoped by
  `user_id`) — **not** on local disk; Render's disk is ephemeral.

**AI features** (`ai_routes.py`) — same contracts as the n8n webhooks they replaced
- `POST /support-resistance` — Gemini refines/confirms the computed pivot
  levels; falls back to computed-only if the LLM response doesn't parse.
- `POST /trade-chat` — conversational Q&A over the caller's own trade
  history; if a message names a symbol with a real logged trade, pulls
  that trade's indicators in as extra context.
- `POST /backtest-ai` — "Configure with AI" panel on the Backtester tab;
  each turn returns `{reply, config?, status: "asking"|"ready"}`.

**Import** (`import_routes.py`, `backtest_import_routes.py`) — auth-gated
- `POST /import-trades` — CSV upload → FIFO match → chart → AI verdict →
  publish, the same pipeline the daily sync uses. Requires the caller's
  Supabase token (an upload has no other way to know whose data it is).
- `GET /import-trades/<job_id>` / `POST /import-trades/<job_id>/cancel`
- `POST /backtest-import` — "Send to Journal" on a backtest run; responds
  immediately, does the real work in a background thread, merges results
  into that run's own report via `/backtest/history/<job_id>/enrich`.

**Execution data kept through matching** (`trade_matching.py`)
- Per fill: real commission on the entry and on the exit (`commission_entry / commission_exit`), broker order id and
  exchange for each side. Per trade: `Commission In / Out` (always sums to `Commission`), `Venues`
  (`{exchange: {sh, comm}}`), `Issuer Country`, `Sub Category`, `Fees`.
- `read_csv_sections` reads each section of an IBKR CSV against its own header (trades, taxes/fees);
  fee rows are tied to trades through the order id. `/import-trades` returns `fee_info`.
- `publish.py` only sends `commission_in/out`, `issuer_country/sub_category`, `fees/venues` once the matching
  columns exist (frontend repo: `sql/003`-`005`).

**Daily sync** (`daily_sync.py` + `publish.py`)
- `POST /daily-sync` — for each active account that has its own Flex token + query ID in `account_flex` (falls back to the old
  `broker_accounts` row for users with none), writing `last_sync_*` back for the Accounts page: pull the IBKR
  Flex report, FIFO-match fills, generate chart + AI verdict per trade,
  publish to Supabase (`trades` + `trade_details`, recomputing
  `equity_after` across the account's full history, not just the new
  batch). Triggered by GitHub Actions (`daily-sync.yml`: every 2 hours 13:05-21:05 UTC on weekdays plus 22:30 UTC after the close;
  trades already saved are skipped before any chart/AI work, so a run with nothing new costs one IBKR request per account. Cost guards: max `SYNC_MAX_NEW_TRADES_PER_RUN` (15) new trades per account per run; a trade whose chart can't be built is NEVER saved without it: it is retried every run for the first `SYNC_FAST_RETRIES` (2) failures, then at most once per `SYNC_RETRY_COOLDOWN_HOURS` (20). Failed-attempt counts and the last error live in `user_kv` key `sync_attempts`. After each account the sync also writes `user_kv` key `sync_report` (`{accounts: {<account_id>: {at, open_positions, no_chart, skipped, deferred}}}`): still-open positions, trades stuck without a chart (reason, attempts, next retry) and ignored/unsaved fills. The Accounts page shows it as "Sync details" and turns the pill amber when `no_chart` is non-empty). `POST /sync-now` (Bearer = the user's Supabase token, body `{account_id}`) syncs just that user's one account on demand (`SYNC_NOW_COOLDOWN_SECONDS`, default 90); the report's `statement` field records the period, fill count and latest fill IBKR sent — the workflow just POSTs and returns; this also doubles
  as a wake-up ping for Render's free tier. Can also be triggered manually
  from the Actions tab (`workflow_dispatch`).

### Added in the Oct 2026 audit fixes

- `MAX_UPLOAD_MB` (default 25): requests with a larger body are rejected with a JSON 413 before being read into memory.
- `GET /import-trades/<job_id>` and `POST /import-trades/<job_id>/cancel` now require `Authorization: Bearer <token>` and only answer for the job's owner (anyone else gets 404, same as an unknown id). Job files written before this change have no owner and are treated as not found.
- `push.bat` does a plain `git push` (no `--force`).
- `.github/workflows/tests.yml` runs `pytest` on every push.

## Auth model

Two different patterns, by design:

- Everything the **frontend reads directly from Supabase** (dashboard,
  journal, stats, etc.) goes through the Supabase JS client with the
  **anon key** — Row Level Security scopes every query to `auth.uid()`
  automatically. No server-side involvement.
- Everything **this service writes**, it writes with the **service role
  key**, which bypasses RLS — because the daily sync writes into
  potentially many different users' rows. So any endpoint that writes on
  behalf of a specific person (`/import-trades`, `/backtest/*`,
  `/backtest-import`) has to know *whose* data it's touching itself,
  rather than relying on RLS to sort it out. That's what
  `supabase_auth.resolve_user_id()` does: takes the `Authorization: Bearer
  <token>` header the browser already has from its own logged-in session,
  verifies it against Supabase's `/auth/v1/user` endpoint, and recovers
  the user id server-side. A forged/expired/missing token is rejected
  with 401 before anything is parsed.
- The daily sync pipeline never needs this — it already knows the user
  from the `broker_accounts` row it's processing.

## Environment variables

| Var | Required | Notes |
|---|---|---|
| `POLYGON_API_KEY` | yes | Consolidated-tape market data |
| `GEMINI_API_KEY` | yes | Vision-LLM verdicts, chat, S/R, backtest-AI |
| `GEMINI_MODEL` | no | default `gemini-3.5-flash-lite` |
| `SUPABASE_URL` | yes | |
| `SUPABASE_SERVICE_ROLE_KEY` | yes | **Never** expose client-side — server only |
| `TELEGRAM_BOT_TOKEN` | no | optional daily-sync failure alerts |
| `PORT` | no | default 5001 (Render sets this itself) |
| `CHART_WINDOW_BEFORE_MIN` / `_AFTER_MIN` | no | default 90 / 30 |
| `CHART_LOOKBACK_DAYS` | no | default 5 (EMA/MACD warm-up) |
| `ENABLE_VOLUME_FLOAT_STATS` | no | default true |
| `VOLUME_STATS_LOOKBACK_DAYS` | no | default 30 |
| `SR_LOOKBACK_DAYS_DEFAULT` | no | default 40 |
| `TICK_DATA_MAX_TRADES` | no | default 2000 |
| `POLYGON_BATCH_SIZE` / `_WINDOW_S` / `_MIN_GAP_S` | no | rate limiting, tuned for Polygon's free tier |
| `IMPORT_RUNS_DIR` / `DAILY_SYNC_RUNS_DIR` | no | local job-progress scratch dirs |

## Deployment

Runs on Render as a standard Python web service (`python chart_service.py`,
reads `PORT` from the environment). `requirements.txt` covers it
(`flask`, `requests`, `pandas`, `mplfinance`, `matplotlib`, `tzdata`).

GitHub Actions (`daily-sync.yml`) hits `POST {RENDER_SERVICE_URL}/daily-sync`
on weekdays (every 2 hours 13:05-21:05 UTC plus 22:30 UTC) — set the `RENDER_SERVICE_URL` and
`DAILY_SYNC_SECRET` repo secrets. Both workflow files must live in `.github/workflows/`:
`daily-sync.yml` (the sync) and `keepalive.yml` (pings `/health` every 10 minutes, 08:00-14:50 UTC, to keep the pre-market scanner alive).

## Browser error reports

`POST /client-errors` (`client_errors.py`) receives uncaught errors from the web app's safety net
(`js/app-boot.js`) so they appear in Render's logs even when you weren't the one at the screen.
Search the log stream for `client-error`: each hit is one JSON line (time, kind, message, page, stack,
browser, and the first 8 characters of the user id). It needs a signed-in user, caps each body at
8 KB, and rate-limits per IP (60 / 10 min) and per user (30 / hour).

## Local development (optional)

`start_chart_service.ps1` / `run.bat` are leftover from before this was
deployed on Render: they start Flask locally and tunnel it through ngrok
so a local instance could be reached from outside. Still fine to use for
local testing, but note the URL it prints is **not** the production
Render URL — don't paste it into `config.js` for a real deployment.

Create `polygon.env.ps1` next to the script (already gitignored — see
below) with:
```powershell
$env:POLYGON_API_KEY = "your_polygon_api_key_here"
```

⚠️ **A previous version of this file had a real, live Polygon API key
hardcoded in it and got shared outside this machine. That key should be
treated as compromised — rotate it in your Polygon dashboard and update
whatever's set in your Render environment variables and any local
`polygon.env.ps1`.** Same goes for the Gemini API key if it was ever
hardcoded anywhere outside an environment variable (check any n8n export
before sharing it — see the frontend repo's history notes).

Add a `.gitignore` here with at least:
```
polygon.env.ps1
*.env
ngrok.log
```

## History / cleanup notes

- `backtest_history.json` and `backtest_reports/*.json` used to be the
  on-disk store for backtest history. Both were removed from this repo —
  storage moved to Supabase (`backtest_runs` table, see
  `backtest_storage.py`) because Render's disk doesn't survive a redeploy.
  If you're restoring from an older copy of this repo, don't bring those
  files back; they're not read by anything anymore.
- This service replaces an n8n workflow that used to sit in front of
  Gemini for Support/Resistance, Chat, and Backtest-AI, and a separate
  n8n branch for the daily IBKR sync and CSV import. All of that logic now
  lives here. If an `n8n/chat-workflow.json` export still exists anywhere
  from that era, treat it as sensitive — earlier versions of it had a live
  Gemini key hardcoded in a node's query parameters.
